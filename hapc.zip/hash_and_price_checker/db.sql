BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "setting" (
	"type"	VARCHAR(1000),
	"text"	VARCHAR(1000),
	PRIMARY KEY("type")
);
CREATE TABLE IF NOT EXISTS "users" (
	"user_id"	BIGINT(10),
	PRIMARY KEY("user_id")
);
CREATE TABLE IF NOT EXISTS "groups" (
	"group_id"	TEXT,
	"start_time"	TEXT,
	PRIMARY KEY("group_id")
);
INSERT INTO "setting" ("type","text") VALUES ('sendalltext','تست پیام همگانی'),
 ('sendallstatus','NULL'),
 ('forwardallmsgid','NULL'),
 ('forwardallstatus','NULL');
COMMIT;
