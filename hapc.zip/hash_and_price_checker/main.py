from os import system, name

libraries = ["python-telegram-bot", "requests", "bs4", "aiocron", "aiohttp", "jdatetime", "telebot"]
for lib in libraries:
    try:
        exec(f"import {lib}")
        print("imported " + lib)
    except:
        system(f"pip install --upgrade {lib}")
        print(f"installed {lib}")

if name == "nt":
    system("cls")
else:
    system("clear")

from time import sleep
import requests, re
from configs import api_key, start_text, admin_id, bot_just_work_in_groups, exchanges
from telebot.async_telebot import AsyncTeleBot as tc2
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
import asyncio
import logging
from datetime import datetime
from bs4 import BeautifulSoup
from re import findall
from requests import get
from sqlite3 import connect

you_are_admin_text = " شما ادمین ربات هستید " + " از پنل زیر می توانید اقدام به مدیریت ربات کنید "
admin_markup = ReplyKeyboardMarkup(row_width=2)
admin_markup.add(KeyboardButton("پیام همگانی به گروه ها"), KeyboardButton("آمار"))
admin_cancel_markup = ReplyKeyboardMarkup(row_width=1)
admin_cancel_markup.add(KeyboardButton("بازگشت"))
BASE_URL = "https://api.blockcypher.com/v1/btc/main"
REDIRECT_BASE_URL = "https://live.blockcypher.com/btc"

conn = connect("data.db")
cursor = conn.cursor()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO)

# ======================= client ===========================
bot = tc2(token=api_key)


def get_span_class():
    response = get("https://coinmarketcap.com/currencies/bitcoin/")
    text_result = response.text
    spin_classes = findall('<span class="sc-.......... ...... base-text">...,......</span>', text_result)
    spin_class = spin_classes[0]
    spin_class = spin_class.replace('<span class="', '')
    spin_class.replace(spin_class[spin_class.index('base-text">') + 11:], '')
    spin_class = spin_class.replace(spin_class[-19:], "")
    return spin_class


def safe_eval(expr):
    allowed_pattern = re.compile(r'^[\d\.\+\-\*/\(\)\s]+$')
    if not allowed_pattern.match(expr):
        return False
    return eval(expr, {"__builtins__": None}, {})


def is_valid_trx_hash(trxhash):
    """
    Validate a TRON transaction hash (trxhash).

    :param trxhash: The transaction hash to validate.
    :return: True if the hash is valid, False otherwise.
    """
    # Check if the hash is exactly 64 characters long
    if len(trxhash) != 64:
        return False

    # Check if the hash contains only valid hexadecimal characters
    if re.fullmatch(r'[a-f0-9]{64}', trxhash):
        return True

    return False


def get_transaction_info(trx_hash):
    def format_number(input_str):
        input_str = str(input_str)
        integer_part = input_str[:3]
        decimal_part = input_str[3:]
        formatted_number = f"{integer_part}.{decimal_part}"
        return formatted_number

    url = f"https://api.tronscan.org/api/transaction-info?hash={trx_hash}"

    response = requests.get(url)

    if response.status_code != 200:
        return False

    try:
        transaction = response.json()
        try:
            status = transaction['contractRet']
        except:
            status = "Not Found"
        hash = trx_hash

        # Some fields might have different names or structures
        if "trc20TransferInfo" in list(transaction.keys()):
            unit = "USDT"
        else:
            unit = "TRX"
        try:
            timestamp = datetime.fromtimestamp(transaction['timestamp'] / 1000)
        except:
            timestamp = 'Not Found'
        try:
            amount = format_number(transaction['contractData']['amount'])
        except:
            amount = 'Not Found'
        try:
            from_address = transaction['ownerAddress']
        except:
            from_address = 'Not Found'
        try:
            to_address = transaction['toAddress']
        except:
            to_address = "Not Found"
        status_emojy = ""
        try:
            status_emojy = "✅" if status == "SUCCESS" else "❌"
        except:
            pass

        result = f"""
{status_emojy} TRANSACTION STATUS: *{status}*

🔍 HASH: `{hash}`

📆 TIME: `{timestamp.strftime('%Y/%m/%d %H:%M:%S')}`

💰 TRANSACTION AMOUNT: `{amount}` {unit}

📤 FROM: `{from_address}`

📥 TO: `{to_address}`

🔗 Link: https://tronscan.org/#/transaction/{trx_hash}
"""
        return result
    except:
        return False


def ton_price():
    return get_coin_price("toncoin")


def get_tron_balance(address):
    url = f"https://api.tronscan.org/api/account?address={address}"
    response = get(url)

    if response.status_code == 200:
        data = response.json()
        balance_sun = int(data['balance'])
        balance_trx = balance_sun / 1e6
        return balance_trx
    else:
        return None


def get_ton_balance(address):
    url = f"https://toncenter.com/api/v2/getAddressInformation?address={address}"
    response = get(url)

    if response.status_code == 200:
        data = response.json()
        balance_nano_ton = int(data['result']['balance'])
        balance_ton = balance_nano_ton / 1e9
        return balance_ton
    else:
        return None


def get_ethereum_balance(address, api_key="RB75YHPCMS18KCHNP61Z4Y6UM557379IR8"):
    url = f"https://api.etherscan.io/api?module=account&action=balance&address={address}&tag=latest&apikey={api_key}"
    response = get(url)

    if response.status_code == 200:
        data = response.json()
        balance_wei = int(data['result'])
        balance_eth = balance_wei / 1e18
        return balance_eth
    else:
        return None


def get_bitcoin_balance(address):
    url = f"https://blockchain.info/q/addressbalance/{address}"
    response = get(url)

    if response.status_code == 200:
        balance_satoshi = int(response.text)
        balance_btc = balance_satoshi / 1e8
        return balance_btc
    else:
        return None


def get_wallet_balance(address):
    if address.startswith('1') or address.startswith('3') or address.startswith('bc1'):
        try:
            balance = get_bitcoin_balance(address), "Bitcoin"
            if balance:
                return balance
        except:
            pass
    elif address.startswith('0x'):
        try:
            balance = get_ethereum_balance(address), "Ethereum(ETH)"
            if balance:
                return balance
        except:
            pass
    elif address.startswith('T'):
        try:
            balance = get_tron_balance(address), "TRX"
            if balance:
                return balance
        except:
            pass
    else:
        try:
            balance = get_ton_balance(address), "TON"
            if balance:
                return balance
        except:
            pass
        return False


def notcoin_price():
    req = get('https://coinmarketcap.com/currencies/notcoin/')
    response = str(req.content)
    res = findall('0.[0-9][0-9][0-9][0-9]', response)
    print(res)
    if res:
        result = res[1].replace('$', '')
        result = result.replace(' ', '')
        return result
    else:
        res = findall('0.[0-9][0-9][0-9]', response)
        result = res[1].replace('$', '')
        result = result.replace(' ', '')
        return result


def bitcoin_price():
    response = get('https://api.coindesk.com/v1/bpi/currentprice.json')
    data = response.json()
    return data["bpi"]["USD"]["rate"]


def is_int(value: str):
    val = value.replace(' ', '')
    val = val.replace(',', '')
    try:
        int(val)
        return True
    except:
        return False


def dollar_price():
    req = get('https://alanchand.com/en/currencies-price/usd-hav')
    response = req.text
    res = findall('1 US dollar is equal to [0-9][0-9],[0-9][0-9][0-9] Iranian Toman', response)
    if res:
        result = res[0].replace('1 US dollar is equal to ', '')  #x
        result = result.replace(' Iranian Toman', '')
        result = result.replace(' ', '')
        result = result.replace(',', '')
        return float(result)
    else:
        res = findall('1 US dollar is equal to [0-9][0-9],[0-9][0-9] Iranian Toman', response)
        result = res[0].replace('1 US dollar is equal to ', '')
        result = result.replace(' Iranian Toman', '')
        result = result.replace(' ', '')
        result = result.replace(',', '')
        return float(result)


def get_coin_price(coin_name):
    url = f'https://coinmarketcap.com/currencies/{coin_name}/'
    span_class = get_span_class()
    response = get(url)
    print(response.status_code == 200)

    if response.status_code == 200:
        html_content = response.text

        soup = BeautifulSoup(html_content, 'html.parser')

        span_element = soup.find('span', class_=span_class)
        if span_element:
            coin_price = span_element.get_text().strip()
            coin_price = coin_price.replace(",", '')
            return float(coin_price[1:])
        else:
            return 'Span element not found'
    else:
        return 'Failed to retrieve the page'


def get_wallet_history(wallet_address, standard, contract_address):
    url = f"https://api.trongrid.io/v1/accounts/{wallet_address}/transactions/{standard}?&contract_address={contract_address}"
    response = requests.get(url)
    if response.status_code == 200:
        response_json = response.json()
        return response_json


def insert_user(user):
    cursor.execute(f"SELECT COUNT(*) FROM `users` WHERE `user_id` = '{user}'")
    result = cursor.fetchone()
    if result[0] == 0:
        cursor.execute(
            f"INSERT INTO `users` (`user_id`, `step`) VALUES ('{user}', 'none');")
        conn.commit()


def insert_group(group_id):
    cursor.execute(f"SELECT COUNT(*) FROM `groups` WHERE `group_id` = '{group_id}'")
    result = cursor.fetchone()
    if result[0] == 0:
        cursor.execute(
            f"INSERT INTO `groups` (`group_id`, `start_time`, `active`) VALUES ('{group_id}', '{str(datetime.now()).split('.')[0]}', 'ON');")
        conn.commit()


@bot.message_handler(commands=['start'])
async def start_bot(event):
    chat_id = event.chat.id
    if int(chat_id) > 0:
        if int(chat_id) == int(admin_id):
            await bot.send_message(chat_id, you_are_admin_text, reply_markup=admin_markup)
        else:
            await bot.reply_to(event, bot_just_work_in_groups)
        insert_user(chat_id)
        return
    else:
        insert_group(chat_id)
        await bot.reply_to(event, start_text)


def query(query):
    result = cursor.execute(query)
    conn.commit()
    return result


def set_step(user, step):
    query(f"UPDATE `users` SET `step` = '{step}' WHERE `user_id` = '{user}'")


@bot.message_handler(func=lambda message: True)
async def reply(event):
    try:
        try:
            sendallstatus = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendallstatus'").fetchone()[0]
            sendalltext = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendalltext'").fetchone()[0]
            if sendallstatus == "ON":
                query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendalltext'")
                query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendallstatus'")
                cursor.execute('SELECT * FROM groups')
                rows = cursor.fetchall()
                results = {'success: ': 0}
                stats = []
                await bot.send_message(admin_id, "✅ارسال پیام همگانی شروع شد")
                for row in rows:
                    userid = row[0]
                    try:
                        sleep(1)
                        await bot.send_message(int(userid), sendalltext)
                    except Exception as e:
                        if e in results.keys():
                            results[e] += 1
                        else:
                            results[e] = 1
                            stats.append(e)
                    else:
                        results['success: '] += 1
                await bot.send_message(admin_id, "✅ارسال پیام همگانی پایان یافت")
                await bot.send_message(admin_id, "نتیجه")
                for r in stats:
                    await bot.send_message(admin_id, str(results[r]))
        except:
            pass
        message_ = event
        message_id = message_.id
        msg = event.text.replace(" ", '')
        chat_id = event.chat.id
        if int(chat_id) > 0 and int(chat_id) != int(admin_id):
            await bot.reply_to(event, bot_just_work_in_groups)
            insert_user(chat_id)
            return
        if int(chat_id) < 0:
            insert_group(chat_id)
        print(msg, chat_id)
        try:
            result = safe_eval(msg)
        except:
            pass
        else:
            if result != msg and result != msg.replace(" ", "") and result:
                await bot.reply_to(event, result)
        for ex in exchanges.notcoin_text:
            if ex in msg:
                try:
                    num = float(msg.replace(ex, ''))
                except:
                    break
                n = notcoin_price()
                d = str(dollar_price()).replace(',', '')
                d = d.replace(' ', '')
                nt = float(float(n) * float(d))
                await bot.reply_to(event,
                                   f'''#Notcoin\n*{num:,} not = {(num * float(n)):,} $\n\n{nt * num:,} toman\n\n1 not = {n} $ \n{float(nt):,} toman *\n\n@hash_checker''')
                return None

        if msg in exchanges.notcoin_text:
            n = notcoin_price()
            d = str(dollar_price()).replace(',', '')
            d = d.replace(' ', '')
            nt = float(float(n) * float(d))
            await bot.reply_to(event, f'''#Notcoin\n*not = {n} $\n{nt:,} Toman *\n@hash_checker''')

        for ex in exchanges.bitcoin_text:
            if ex in msg:
                try:
                    num = float(msg.replace(ex, ''))
                except:
                    break
                n = bitcoin_price().replace(',', '')
                d = str(dollar_price()).replace(',', '')
                d = d.replace(' ', '')
                nt = float(float(n) * float(d))
                await bot.reply_to(event,
                                   f'''#Bitcoin\n*{num:,} bitcoin = {(num * float(n)):,} $\n\n{nt * num:,} toman\n\n1 bitcoin = {float(n):,} $ \n{float(nt):,} toman *\n\n@hash_checker''')

        if msg in exchanges.bitcoin_text:
            b = bitcoin_price().replace(',', '')
            b = b.replace("'", '')
            b = b.replace('"', '')
            bt = float(b.replace(',', ''))
            d = float(str(dollar_price()).replace(',', ''))
            await bot.reply_to(event,
                               f'''#Bitcoin\n*bitcoin = {float(float(b)):,} $\n{float(bt * d):,} Toman *\n\n@hash_checker''')

        for ex in exchanges.dollar_text:
            if ex in msg:
                try:
                    num = float(msg.replace(ex, ''))
                except:
                    break
                d = str(dollar_price()).replace(',', '')
                d = d.replace(' ', '')
                nt = float(float(num) * float(d))
                await bot.reply_to(event,
                                   f'''#Dollar\n*{num:,} dollar US = {float(float(nt)):,} Toman \n\n1 dollar US = {float(d):,}*\n\n@hash_checker''')

        if msg in exchanges.dollar_text:
            await bot.reply_to(event, f'''#Dollar\n*dollar US: {dollar_price()} Toman *\n\n@hash_checker''')

        for ex in exchanges.ton_text:
            if ex in msg:
                try:
                    num = float(msg.replace(ex, ''))
                except:
                    break
                n = ton_price()
                d = str(dollar_price()).replace(',', '')
                d = d.replace(' ', '')
                nt = float(float(n) * float(d))
                await bot.reply_to(event,
                                   f'''#Toncoin\n*{num:,} toncoin = {(num * float(n)):,} $\n\n{nt * num:,} toman\n\n1 toncoin = {n} $ \n{float(nt):,} toman *\n\n@hash_checker''')

        if msg in exchanges.ton_text:
            b = str(ton_price()).replace(',', '')
            bt = float(b.replace(',', ''))
            d = float(str(dollar_price()).replace(',', ''))
            await bot.reply_to(event,
                               f'''#Toncoin\n*ton = {float(b):,} $\n{float(bt * d):,} Toman *\n\n@hash_checker''')

        for ex in exchanges.trx_texts:
            if ex in msg:
                try:
                    num = float(msg.replace(ex, ''))
                except:
                    break
                n = str(get_coin_price("tron")).replace(',', '')
                d = str(dollar_price()).replace(',', '')
                d = d.replace(' ', '')
                nt = float(float(n) * float(d))
                await bot.reply_to(event,
                                   f'''#Trx #Tron\n*{num:,} trx = {(num * float(n)):,} $\n\n{nt * num:,} toman\n\n1 trx = {float(n):,} $ \n{float(nt):,} toman *\n\n@hash_checker''')

        if msg in exchanges.trx_texts:
            b = str(get_coin_price("tron")).replace(',', '')
            b = b.replace("'", '')
            b = b.replace('"', '')
            bt = float(b.replace(',', ''))
            d = float(str(dollar_price()).replace(',', ''))
            await bot.reply_to(event,
                               f'''#Trx\n*trx = {float(float(b)):,} $\n{float(bt * d):,} Toman *\n\n@hash_checker''')
        if chat_id == admin_id and msg.startswith('/exec:'):
            try:
                exec(msg.replace("/exec:", ''))
            except Exception as e:
                await bot.reply_to(event, f"Error:\n{e}")
            else:
                await bot.reply_to(event, "Successfully Executed.")
        """if msg.startswith("history:"):
            msg_ = msg.replace("history:", '').split("\n")
            if len(msg_) == 1:
                wallet = msg_[0]
                s = "trc20"
                c = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
            elif len(msg_) == 2:
                wallet = msg_[0]
                s = msg_[1]
                c = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
            elif len(msg_) == 3:
                wallet = msg_[0]
                s = msg_[1]
                c = msg_[2]
            else:
                await bot.reply_to(event, "BAD INPUT")
                return
            try:
                response = get_wallet_history(wallet, s, c)
            except Exception as e:
                await bot.reply_to(event, f"Error:\n{e}")
                return
            await bot.reply_to(event, str(response))"""
        if is_valid_trx_hash(msg):
            try:
                check_hash_result = get_transaction_info(msg)
            except:
                check_hash_result = False
            if check_hash_result:
                await bot.reply_to(event, check_hash_result, parse_mode='Markdown')

        if msg.startswith("price:") or msg.startswith("/price:") or msg.startswith("Price:"):
            coin_name = msg.replace("price:", "")
            coin_name = coin_name.replace("/price:", "")
            coin_name: str = coin_name.replace("Price:", "")
            coin_name: str = coin_name.lower()
            if coin_name == 'trx':
                coin_name = "tron"
            price = get_coin_price(coin_name)
            if price != 'Span element not found' and price != 'Failed to retrieve the page':
                await bot.reply_to(event, f"Price: {price:,} $\n{price * dollar_price():,} toman")
                return
            else:
                await bot.reply_to(event, "Sorry, Price Not Found")
                return

        try:
            balance_amount = get_wallet_balance(msg)
            balance, amount = balance_amount[0], balance_amount[1]
            if balance:
                await bot.reply_to(event, f"Balance: {balance} {amount}")
        except:
            pass

        if int(chat_id) == int(admin_id):
            step = cursor.execute(f"SELECT `step` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
            if msg == "پیام همگانی به گروه ها" and step == "none":
                sendallstatus = \
                    cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendallstatus'").fetchone()[0]
                if sendallstatus == "ON":
                    await event.reply("‼️لطفا تا پایان ارسال پیام همگانی قبلی, پیام همگانی جدیدی ثبت نکنید")
                    return
                set_step(chat_id, "send_all")
                await bot.send_message(chat_id, "پیام مورد نظر را برای ارسال همگانی به گروه ها ارسال کنید",
                                       reply_markup=admin_cancel_markup)
                return
            elif step == "send_all":
                if msg == "بازگشت" or msg == "/start":
                    set_step(chat_id, "none")
                    return
                query(f"UPDATE `setting` SET `text` = '{msg}' WHERE `type` = 'sendalltext'")
                query(f"UPDATE `setting` SET `text` = 'ON' WHERE `type` = 'sendallstatus'")
                set_step(chat_id, "none")
                await bot.send_message(chat_id,
                    "✅پیام شما در صف ارسال قرار گرفت.\n\n‼️توجه : لطفا تا پایان ارسال این پیام , پیام همگانی جدیدی ثبت نکنید",
                    reply_markup=admin_markup)
                sendallstatus = \
                    cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendallstatus'").fetchone()[0]
                sendalltext = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendalltext'").fetchone()[0]
                if sendallstatus == "ON":
                    query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendalltext'")
                    query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendallstatus'")
                    cursor.execute('SELECT * FROM groups')
                    rows = cursor.fetchall()
                    results = {'success: ': 0}
                    stats = []
                    await bot.send_message(admin_id, "✅ارسال پیام همگانی شروع شد")
                    for row in rows:
                        userid = row[0]
                        try:
                            sleep(1)
                            await bot.send_message(int(userid), sendalltext)
                        except Exception as e:
                            if e in results.keys():
                                results[e] += 1
                            else:
                                results[e] = 1
                                stats.append(e)
                        else:
                            results['success: '] += 1
                    await bot.send_message(admin_id, "✅ارسال پیام همگانی پایان یافت")
                    await bot.send_message(admin_id, "نتیجه")
                    for r in stats:
                        await bot.send_message(admin_id, str(results[r]))
                set_step(chat_id, 'none')

            if msg == "آمار":
                active_groups_len = cursor.execute(f"SELECT COUNT(*) FROM `groups` WHERE `active` = 'ON'").fetchone()[0]
                users_len = cursor.execute(f"SELECT COUNT(*) FROM `users`").fetchone()[0]
                text = f"""
                ربات شما تا کنون دارای {users_len} کاربر در پیوی است و در {active_groups_len} گروه فعال است
                """
                set_step(chat_id, "none")
                await bot.send_message(chat_id, text, reply_markup=admin_markup)


    except Exception as e:
        await bot.send_message(admin_id, str(e))


if __name__ == "__main__":
    print("Bot Is Running...")
    asyncio.run(bot.infinity_polling())
