admin_id = 6556061698
api_key = ""  # get it from bot father
start_text = """
The bot is started, Admin the bot to use it 🤗😃
Bot Developer: @linux7563_def

بات استارت شد، بات را ادمین کنید تا بتوانید از آن استفاده کنید.
توسعه دهنده بات: linux7563_def@
"""


bot_just_work_in_groups = "This Bot Not Work In PrivateChat So Please Add In Group And Enjoy Use It"


class exchanges:
    notcoin_text = ['not', 'notcoin', 'نات', 'ناتکوین', 'Not', 'Notcoin']
    bitcoin_text = ['bit', 'bitcoin', 'بیت', 'بیتکوین', "Bitcoin", "Bit"]
    dollar_text = ['dollar', 'دلار', '$', 'Dollar']
    ton_text = ['ton', 'toncoin', 'تون', 'تونکوین', 'Ton', 'Toncoin', 'Toncoin', 'TonCoin', 'TonCoin']
    trx_texts = ['trx', 'tron', 'ترون', 'تی آر ایکس', 'TRX', "Trx", 'Tron', 'TRON']


"""
Developer:  @linux7563_def
Channel  :  @linux7563_tv
this source channel: @hash_checker
"""
